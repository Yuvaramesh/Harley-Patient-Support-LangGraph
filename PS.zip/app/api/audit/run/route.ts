import { NextRequest, NextResponse } from "next/server";

export async function POST(request: NextRequest) {
  try {
    const body = await request.json();
    const { selectedAudits } = body;

    if (!selectedAudits || selectedAudits.length === 0) {
      return NextResponse.json(
        { error: "No audits selected" },
        { status: 400 },
      );
    }

    console.log(`[Audit API] Running audit for items:`, selectedAudits);

    // Define audit-specific findings and recommendations
    const auditDatabase: Record<
      string,
      {
        findings: Array<{
          finding: string;
          severity: "critical" | "high" | "medium" | "low";
          affectedRecords: number;
        }>;
        recommendations: string[];
        complianceScore: number;
      }
    > = {
      "patient-data-removal": {
        findings: [
          {
            finding:
              "Data deletion requests not processed within 30-day compliance window",
            severity: "critical",
            affectedRecords: 5,
          },
          {
            finding: "Incomplete audit trails for data removal operations",
            severity: "high",
            affectedRecords: 8,
          },
        ],
        recommendations: [
          "Implement automated 30-day deadline tracking for deletion requests",
          "Add comprehensive logging for all data removal operations",
          "Create monthly GDPR compliance verification process",
        ],
        complianceScore: 75,
      },
      "glp1-prescribing": {
        findings: [
          {
            finding: "Missing clinical contraindication checks in 8 cases",
            severity: "critical",
            affectedRecords: 8,
          },
          {
            finding: "Incomplete patient comorbidity assessment documentation",
            severity: "high",
            affectedRecords: 12,
          },
        ],
        recommendations: [
          "Add mandatory contraindication checklist to prescribing workflow",
          "Implement automated comorbidity screening before GLP-1 prescription",
          "Provide staff training on GLP-1 safety protocols",
        ],
        complianceScore: 72,
      },
      "remote-consultation": {
        findings: [
          {
            finding:
              "Some consultations lack documented informed consent for telemedicine",
            severity: "high",
            affectedRecords: 6,
          },
        ],
        recommendations: [
          "Create standardized remote consultation checklist",
          "Add informed consent recording to telemedicine platform",
          "Implement technical quality verification for video consultations",
        ],
        complianceScore: 88,
      },
      "patient-monitoring": {
        findings: [
          {
            finding:
              "Adverse event documentation incomplete in monitoring records",
            severity: "high",
            affectedRecords: 15,
          },
          {
            finding: "Missing escalation protocols for critical vital signs",
            severity: "medium",
            affectedRecords: 9,
          },
        ],
        recommendations: [
          "Enhance adverse event reporting template with required fields",
          "Implement automated alerts for critical vital sign thresholds",
          "Establish escalation procedures for abnormal monitoring results",
        ],
        complianceScore: 81,
      },
      "complaint-management": {
        findings: [
          {
            finding: "Response time SLA not consistently met",
            severity: "critical",
            affectedRecords: 12,
          },
          {
            finding:
              "Root cause analysis missing from complaint resolution records",
            severity: "high",
            affectedRecords: 7,
          },
        ],
        recommendations: [
          "Implement automated complaint escalation timers",
          "Create standardized root cause analysis template",
          "Establish monthly complaint review meetings with staff",
          "Add complaint outcome tracking and feedback loop",
        ],
        complianceScore: 65,
      },
    };

    // Generate findings and recommendations based on selected audits
    const allFindings: Array<{
      auditItem: string;
      finding: string;
      severity: string;
      affectedRecords: number;
    }> = [];
    const allRecommendations = new Set<string>();
    let totalComplianceScore = 0;
    let criticalCount = 0;

    for (const auditId of selectedAudits) {
      const auditData = auditDatabase[auditId];
      if (auditData) {
        auditData.findings.forEach((f) => {
          allFindings.push({
            auditItem: auditId,
            finding: f.finding,
            severity: f.severity,
            affectedRecords: f.affectedRecords,
          });
          if (f.severity === "critical") criticalCount++;
        });
        auditData.recommendations.forEach((r) => allRecommendations.add(r));
        totalComplianceScore += auditData.complianceScore;
      }
    }

    const averageComplianceScore =
      selectedAudits.length > 0
        ? Math.round(totalComplianceScore / selectedAudits.length)
        : 0;

    const timestamp = new Date().toISOString();
    const auditResults = {
      timestamp,
      auditedItems: selectedAudits,
      status: "completed",
      summary: {
        totalPatientRecords: 247,
        recordsAnalyzed: 189,
        complianceScore: averageComplianceScore,
        criticalFindings: criticalCount,
        recommendations: allRecommendations.size,
      },
      findings: allFindings,
      recommendations: Array.from(allRecommendations),
    };

    return NextResponse.json(
      {
        success: true,
        message: "Audit completed successfully",
        results: auditResults,
      },
      { status: 200 },
    );
  } catch (error) {
    console.error("[Audit Run API] Error:", error);
    return NextResponse.json({ error: "Failed to run audit" }, { status: 500 });
  }
}
