import { NextRequest, NextResponse } from "next/server";

const AUDIT_ITEMS = [
  {
    id: "patient-data-removal",
    name: "Patient Data Removal Requests",
    regulationCode: "WL-SOP-005",
    status: "compliant",
    completeness: 95,
    description:
      "Processing right to erasure under GDPR with proper documentation and timelines",
    criticalIssues: 0,
    lastReviewed: "2 weeks ago",
  },
  {
    id: "glp1-prescribing",
    name: "GLP-1 Receptor Agonist Prescribing Protocol",
    regulationCode: "WL-SOP-001",
    status: "partial",
    completeness: 78,
    description:
      "Clinical assessment and prescription guidelines for GLP-1 medications",
    criticalIssues: 2,
    lastReviewed: "3 weeks ago",
  },
  {
    id: "remote-consultation",
    name: "Remote Consultation and Patient Assessment Protocol",
    regulationCode: "WL-SOP-002",
    status: "compliant",
    completeness: 92,
    description: "Telemedicine best practices and patient safety protocols",
    criticalIssues: 0,
    lastReviewed: "1 week ago",
  },
  {
    id: "patient-monitoring",
    name: "Patient Monitoring and Adverse Event Management",
    regulationCode: "WL-SOP-003",
    status: "partial",
    completeness: 85,
    description:
      "Ongoing patient safety monitoring and incident response procedures",
    criticalIssues: 1,
    lastReviewed: "4 days ago",
  },
  {
    id: "complaint-management",
    name: "Patient Complaint Management Protocol",
    regulationCode: "WL-SOP-004",
    status: "non-compliant",
    completeness: 45,
    description: "Customer service standards and complaint handling procedures",
    criticalIssues: 5,
    lastReviewed: "6 weeks ago",
  },
];

export async function GET(request: NextRequest) {
  try {
    // Calculate metrics
    const compliantCount = AUDIT_ITEMS.filter(
      (item) => item.status === "compliant",
    ).length;
    const totalCriticalIssues = AUDIT_ITEMS.reduce(
      (sum, item) => sum + item.criticalIssues,
      0,
    );
    const averageScore =
      Math.round(
        (AUDIT_ITEMS.reduce((sum, item) => sum + item.completeness, 0) /
          AUDIT_ITEMS.length) *
          10,
      ) / 10;

    const metrics = {
      totalAudits: AUDIT_ITEMS.length,
      compliantCount,
      complianceScore: Math.round((compliantCount / AUDIT_ITEMS.length) * 100),
      patientsSeen: 247,
      averageScore,
      criticalIssues: totalCriticalIssues,
    };

    return NextResponse.json(
      {
        audits: AUDIT_ITEMS,
        metrics,
      },
      { status: 200 },
    );
  } catch (error) {
    console.error("[Audit API] Error:", error);
    return NextResponse.json(
      { error: "Failed to fetch audit data" },
      { status: 500 },
    );
  }
}
